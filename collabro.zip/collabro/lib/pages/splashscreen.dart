import 'package:collabro/pages/login.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'dart:async';
import 'package:collabro/products.dart';

class Splashscreen extends StatefulWidget {
  @override
  _SplashscreenState createState() => _SplashscreenState();
}

class _SplashscreenState extends State<Splashscreen> {
  @override
  void initState(){
    super.initState();
    navigateUser();
  }

  navigateUser(){
//    checking if the user is logged in
  FirebaseAuth.instance.currentUser().then((currentUser){
    if(currentUser==null){
      Timer(Duration(seconds: 2),
        ()=> Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>login()))
      );
    }
    else{
      Timer(Duration(seconds: 2),
          ()=>Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>products())));
    }
  });
  }
  Widget build(BuildContext context) {
    return Container(
      height: double.infinity,
      child: Center(
        child: Image.asset("collabroresources/logo.jpg",height: 200,),
      ),
    );
  }
}
