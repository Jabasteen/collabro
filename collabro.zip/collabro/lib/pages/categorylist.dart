import 'package:collabro/widgets/appdrawer.dart';
import 'package:flutter/material.dart';
import 'package:collabro/pages/Items_list.dart';

class categorylist extends StatefulWidget {
  @override
  _categorylistState createState() => _categorylistState();
}

class _categorylistState extends State<categorylist> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(centerTitle: true,
        title: Text('Collabro'),
        backgroundColor: Color.fromRGBO(42,62,112, 1.0),
        elevation: 0.0,),
      drawer: appdrawer,
      body: new item_list_products(),
    );
  }
}
