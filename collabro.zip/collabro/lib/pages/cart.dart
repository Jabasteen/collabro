

import 'package:flutter/material.dart';


import 'package:collabro/components/cart_products.dart';



class CartProducts extends StatefulWidget {
  @override
  _CartProductsState createState() => _CartProductsState();
}

class _CartProductsState extends State<CartProducts> {
  @override
  Widget build(BuildContext context) {

    return Scaffold(
//      backgroundColor: Color.fromRGBO(36,37,53,1.0),
    backgroundColor: Colors.white,

//     ==========AppBar=====

        appBar: new AppBar(
          centerTitle: true,
          title: Text('Cart'),
          backgroundColor: Color.fromRGBO(42,62,112, 1),
          elevation: 0.0,
          actions: <Widget>[
            new IconButton(icon: Icon(Icons.search,color: Colors.white), onPressed: null),
          ],
        ),

      bottomNavigationBar: Container(
        color: Colors.transparent,
        child: new Row(
          children: <Widget>[
            Expanded(
              child: ListTile(
                title: Padding(
                  padding: const EdgeInsets.only(left:1.0,right: 15.0,bottom: 15.0),
                  child: Text("Total :  ₹39,999",style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold,color: Colors.black),),
                ),
                /*subtitle: Padding(
                  padding: const EdgeInsets.only(left: 30.0,top: 7.0),
                  child: Text("₹39,999",style: TextStyle(fontSize: 14,fontWeight: FontWeight.bold,color: Colors.white)),
                ),*/
              ),
            ),
            Expanded(
              child: Container(
                padding: EdgeInsets.only(right: 15.0,bottom: 15.0),
                child: new MaterialButton(onPressed: (){},
                color: Color.fromRGBO(42,62,112, 1),
                  padding: EdgeInsets.all(15.0),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(20.0))),
                  child:
                  new Text("Place Order",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20,color: Colors.white),),
                ),
              ),
            )
          ],
        ),
      ) ,

      body:
        new cart_products()
      );
  }
}
