import 'package:flappy_search_bar/flappy_search_bar.dart';
import 'package:flutter/material.dart';

class explore extends StatefulWidget {
  @override
  _exploreState createState() => _exploreState();
}

class _exploreState extends State<explore> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: <Widget>[
          SearchBar(
            placeHolder: Text("Search"),
          ),
        ],
      ),
    );
  }
}
