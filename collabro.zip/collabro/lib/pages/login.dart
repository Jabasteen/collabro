import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collabro/products.dart';

import 'package:collabro/functions/sign_in.dart';
import 'package:collabro/models/dbproducts.dart';

class login extends StatefulWidget {
  @override
  _loginState createState() => _loginState();
}

class _loginState extends State<login> {
  final FirebaseAuth firebaseAuth = FirebaseAuth.instance;
  final GoogleSignIn googleSignIn = GoogleSignIn();
  SharedPreferences preferences;
  bool loading = false;
  bool isLogedin = false;

  @override
  void initState() {
    super.initState();
    isSignedIn();
  }

  void isSignedIn() async {
    setState(() {
      loading = true;
    });
    preferences = await SharedPreferences.getInstance();
    isLogedin = await googleSignIn.isSignedIn();

    if (isLogedin == true) {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => products()));
    }

    setState(() {
      loading = false;
    });
  }

  Future<String> SignInWithGoogle() async {
    preferences = await SharedPreferences.getInstance();

    setState(() {
      loading = true;
    });

    final GoogleSignInAccount googleSignInAccount = await googleSignIn.signIn();
    final GoogleSignInAuthentication googleSignInAuthentication =
    await googleSignInAccount.authentication;

    AuthCredential authCredential = GoogleAuthProvider.getCredential(
        idToken: googleSignInAuthentication.idToken,
        accessToken: googleSignInAuthentication.accessToken);

    FirebaseUser firebaseUser =
        (await firebaseAuth.signInWithCredential(authCredential)).user;

    if (firebaseUser != null) {
      final QuerySnapshot result = await Firestore.instance
          .collection("users")
          .where("id", isEqualTo: firebaseUser.uid)
          .getDocuments();

      final List<DocumentSnapshot> documents = result.documents;

      if (documents.length == 0) {
//        registering the user in our database
        Firestore.instance.collection("users")
            .document(firebaseUser.uid)
            .setData({
                "id" : firebaseUser.uid,
                "username" : firebaseUser.displayName,
                "profilepicture" : firebaseUser.photoUrl
        });

        await preferences.setString("id",firebaseUser.uid);
        await preferences.setString("username", firebaseUser.displayName);
        await preferences.setString("proilepicture", firebaseUser.photoUrl);
      }else{
        await preferences.setString("id",documents[0]['id']);
        await preferences.setString("username", documents[0]['id']);
        await preferences.setString("proilepicture", documents[0]['id']);
      }

      Fluttertoast.showToast(msg: "Logged in");
      setState(() {
        loading = false;
      });

      Navigator.pushReplacement(

          context, MaterialPageRoute(builder: (context) => products()));

    } else {

      Fluttertoast.showToast(msg: "login failed");

    }
  }

  Future<String> SignOutGoogle() async {
    await googleSignIn.signOut();
    print("User Signed Out");
  }

  @override
  Widget build(BuildContext context) {
//
    return Scaffold(
      body: Container(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.max,
            children: <Widget>[
              Container(
                  child: Center(child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Image.asset("collabroresources/logo.jpg",height: 150.0,),
                  ))),
              signInButton(),
            ],
          ),
        ),
      ),
    );
  }

  Widget signInButton() {
    return OutlineButton(
      splashColor: Colors.grey,
      onPressed: () {
        SignInWithGoogle().whenComplete(() =>
            Navigator.pushReplacement(
                context, MaterialPageRoute(builder: (context) => products())));
      },
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
      borderSide: BorderSide(color: Colors.grey),
      child: Padding(
        padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset(
              "collabroresources/category/google_logo.png",
              height: 30.0,
            ),
            Padding(
              padding: EdgeInsets.only(left: 10),
              child: Text(
                "Sign in with Google",
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
            )
          ],
        ),
      ),
    );
  }
}
