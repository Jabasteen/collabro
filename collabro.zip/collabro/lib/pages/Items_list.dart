import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';




class _item_list_productsState extends State<item_list_products> {
  var Products_on_list = [
    {
      "name": "Yamaha MX88 Music Production Synthesizer",
      "new_price": "79,990",
      "picture": "collabroresources/1.jpg"
    },

    {
      "name": "YAMAHA MODX6 DIGITAL SYNTHESIZER WORKSTATION",
      "new_price": "199,999",
      "picture": "collabroresources/2.jpg"
    },

  ];
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: Products_on_list.length,
        itemBuilder: (context, index) {
          return Single_product(
            product_name: Products_on_list[index]["name"],
            product_price: Products_on_list[index]["new_price"],
            product_image: Products_on_list[index]["picture"],
          );
        });
  }
}

class item_list_products extends StatefulWidget {
  @override
  _item_list_productsState createState() => _item_list_productsState();
}




class Single_product extends StatelessWidget {
  final String product_name;
  final String product_image;
  final String product_price;

  Single_product({
    this.product_image,
    this.product_name,
    this.product_price
  });


  @override
  Widget build(BuildContext context) {
    return Container(
        padding: EdgeInsets.all(8.0),
        child: Card(
          child: Container(
            child: ListTile(
              leading: SizedBox(width:150,
                  height: double.infinity,
                  child: Image.asset(product_image)),
              subtitle: new Column(
                children: <Widget>[
                  new Row(
                    children: <Widget>[
                      Padding(padding: EdgeInsets.only(top: 20.0)),
                      Expanded(
                          child: new Text(product_name,style: TextStyle(
                              fontSize: 18,fontWeight: FontWeight.bold,color: Colors.black),)
                      )
                    ],
                  ),
                  Divider(),
                  new Row(
                    children: <Widget>[
                      Expanded(
                        child: new Text("₹"+product_price,style: TextStyle(
                            fontSize: 18)),
                      ),
                    ],
                  ),
                  Padding(padding: EdgeInsets.only(bottom: 7.0),)
                ],
              ),
            ),
          ),
        )
    );
  }
}
