import 'dart:ui';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:collabro/pages/explore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
//import 'package:google_sign_in/google_sign_in.dart';
//import 'package:firebase_auth/firebase_auth.dart';

//=========MY IMPORTS======

import 'package:collabro/horizontal_list.dart';
import 'package:collabro/recentproducts.dart';
import 'package:collabro/widgets/carousel.dart';
import 'package:collabro/pages/cart.dart';
import 'package:collabro/pages/login.dart';
import 'package:collabro/widgets/appdrawer.dart';



//===========CAROUSEL WIDGET==========


class products extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    //===========APP BAR===============


    return Scaffold(
//      backgroundColor: Color.fromRGBO(36,37,53,1.0),
    backgroundColor: Colors.white,

      appBar: new AppBar(
        centerTitle: true,
        title: Text('Collabro'),
        backgroundColor: Color.fromRGBO(42,62,112, 1.0),
        elevation: 0.0,
        actions: <Widget>[
          new IconButton(icon: Icon(Icons.search,color: Colors.white),

              onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>explore()));
              }),
          new IconButton(icon: Icon(Icons.shopping_cart,color: Colors.white),
              onPressed: () {Navigator.push(context,MaterialPageRoute(builder: (context)=> new CartProducts()));})
        ],
      ),


      //======APP DRAWER===========

      drawer: appdrawer,



//      ============BODY OF THE PRODUCTS PAGE===============

      body:
       Container(
        /*decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color.fromRGBO(54, 44, 125, 1),Color.fromRGBO(27,23, 61, 1)])
        ),*/
         child:  new ListView(


           children: <Widget>[
             new Padding(padding: EdgeInsets.all(0.0),
               child: carouselPro,),
              Divider(),
//             new Padding(padding: EdgeInsets.all(8.0)),//padding
             Text('  Shop by Categories',style: TextStyle(color: Colors.black,fontSize: 22,fontWeight: FontWeight.bold),),
//             new Padding(padding: EdgeInsets.all(5.0)),
             Divider(),
             horizontal_list(),
//             new Padding(padding: EdgeInsets.all(5.0)),
             Divider(),
             Text('  Deals',style: TextStyle(color: Colors.black,fontSize: 22, fontWeight: FontWeight.bold),),
              Divider(),
//             new Padding(padding: EdgeInsets.all(5.0)),
             recentprod(),


           ],
         ),
      ),

    );
  }
}
