import 'package:flutter/material.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:flutter/widgets.dart';

import 'package:collabro/pages/categorylist.dart';
class horizontal_list extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 160.0,
        child: ListView(
          scrollDirection: Axis.horizontal,
          children: <Widget>[
            categories(
              image_location: 'collabroresources/category/piano.png',
              image_caption: 'Piano',
            ),

            categories(
              image_location: 'collabroresources/category/guitar.png',
              image_caption: 'Guitars & Basses',
            ),

            categories(
              image_location: 'collabroresources/category/drums.png',
              image_caption: 'Drums & Percussio',
            ),

            categories(
              image_location: 'collabroresources/category/audiointer.png',
              image_caption: 'Studio & Recording',
            ),

            categories(
              image_location: 'collabroresources/category/flute.png',
              image_caption: 'Wind & String ',
            ),

            categories(
              image_location: 'collabroresources/category/gprocessor.png',
              image_caption: 'Amplifiers & Effects',
            ),
          ],
        ),

    );
  }
}

class categories extends StatelessWidget {
  final String image_location;
  final String image_caption;
  categories(
  {
    this.image_caption,
    this.image_location
}
      );
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top:5.0,bottom: 5.0,left:12.0,right: 12.0),
      child:
      InkWell(
        onTap: (){
          Navigator.push(context, MaterialPageRoute(builder: (context)=> categorylist()));
        },
        child: Container(

          decoration:BoxDecoration(borderRadius: BorderRadius.circular(10.5),
            color: Color.fromRGBO(42,62,112, 1),),

          width: 100.0,

          child: ListTile(

            title: Image.asset(image_location,width: 110.0,height: 100.0,),
            subtitle: Text(image_caption, style: TextStyle(color: Colors.white,
                fontStyle: FontStyle.italic,fontWeight: FontWeight.bold ), textAlign: TextAlign.center, ),

          ),
        ),
      ),
    );
  }
}
