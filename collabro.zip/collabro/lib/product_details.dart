import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:collabro/recentproducts.dart';
import 'package:collabro/pages/cart.dart';

class ProductDetails extends StatefulWidget {
  final product_name_detail;
  final product_image_detail;
  final product_old_price_detail;
  final product_new_price_detail;

  ProductDetails({
    this.product_image_detail,
    this.product_name_detail,
    this.product_old_price_detail,
    this.product_new_price_detail,
  });

  @override
  _ProductDetailsState createState() => _ProductDetailsState();
}

class _ProductDetailsState extends State<ProductDetails> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
//      backgroundColor: Color.fromRGBO(36,37,53,1.0),
      backgroundColor: Colors.white,
      //=======APP BAR===========

      appBar: new AppBar(
        centerTitle: true,
        title: Text('Collabro', style: TextStyle(color: Colors.white),),
        backgroundColor: Color.fromRGBO(42,62,112, 1.0),
        elevation: 0.0,
        actions: <Widget>[
          new IconButton(icon: Icon(Icons.shopping_cart, color: Colors.white),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(
                    builder: (context) => new CartProducts()));
              })
        ],
      ),

      //===========BODY========

      body: ListView(
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(15.0),
            child: Container(
              height: 200.0,
              width: 400,
              padding: const EdgeInsets.all(8.0),

              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(30),
                bottomRight: Radius.circular(0),
                topLeft: Radius.circular(30),
                topRight: Radius.circular(30)),
                color: Colors.white,),
              child: Image.asset(widget.product_image_detail,),
            ),
          ),
          Divider(),
          Container(
            //color: Colors.red,
            padding: EdgeInsets.all(8.0),
              child: Text(widget.product_name_detail,
                style: TextStyle(fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.black),)
          ),
          Divider(),
          new Expanded(
              child: Container(
                padding: EdgeInsets.only(left: 15),
                child: Text("₹ " + widget.product_new_price_detail,
                  style: TextStyle(fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.black),),
              )),

          new Expanded(
              child: Container(
                padding: EdgeInsets.only(left: 15.0, top: 15.0),
                child: Text("MRP: ₹ " + widget.product_old_price_detail,
                  style: TextStyle(fontSize: 15,
                      color: Colors.grey,
                      decoration: TextDecoration.lineThrough),),
              )),
          Container(
            child: Row(
              children: <Widget>[
                new IconButton(icon: Icon(Icons.favorite),
                  onPressed: () {

                  },
                  iconSize: 30.0,
                  color: Colors.grey,
                  padding: EdgeInsets.only(top:20.0,bottom: 20,left: 30,right: 50),),
                Expanded(
                  child: MaterialButton(
                    onPressed: () {

                    },
                    color: Color.fromRGBO(42,62,112, 1.0),
                    elevation: 5.0,
                    height: 45,
                    colorBrightness: Brightness.light,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(30.0))),
                    child: Text("Buy Now", style: TextStyle(color: Colors.white,
                        fontSize: 20,
//                        fontWeight: FontWeight.bold
                    ),
                    ),
                  ),
                ),
                new IconButton(icon: Icon(Icons.add_shopping_cart),
                  onPressed: () {},
                  iconSize: 30.0,
                  color: Colors.grey,
                  padding: EdgeInsets.only(top:20.0,bottom: 20,left: 50,right: 30),),
              ],
            ),
          ),
          Divider(),
          Padding(
            padding: const EdgeInsets.only(top: 0.0, bottom: 0.0, left: 15.0),
            child: new Text("Product Details",
              style: TextStyle(fontSize: 25,
                  fontWeight: FontWeight.bold,
                  color: Colors.black),),
          ),
          Divider(),
          Container(

              decoration: BoxDecoration(borderRadius: BorderRadius.only(
                  topRight: Radius.circular(30.0,),
                  topLeft: Radius.circular(30.0)),
                color: Color.fromRGBO(42,62,112, 1.0),),
              padding: EdgeInsets.all(15.0),
              child: Text("Synthesizer keyboard 88 Graded Hammer Standard "
                  "keys are heavier in the lower register and lighter in the higher"
                  " register for real piano feelFM Essential expands your sonic arsenal"
                  " with iOS FM digital synthesizer app that includes drum loops, FX, and "
                  "more This electronic synthesizer bundle includes synthesizer headphones, "
                  "Keyboard Stand, Keyboard Cover and Synthesizer ClothYamaha synthesizer 88 key "
                  "DAW Remote controls transport, mixer, and software instruments from the MX top panel"
                  " Yamha 88 key synthesizer has 128-note polyphony for dropout-free live performance or "
                  "with full 16-track sequences", style: TextStyle(fontSize: 20,
                  color: Colors.white,
                  letterSpacing: 1.3,
                  wordSpacing: 3.0),)
          ),


        ],
      ),
    );
  }
}
