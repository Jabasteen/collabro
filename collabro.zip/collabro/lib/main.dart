import 'package:flutter/material.dart';
import 'package:collabro/pages/splashscreen.dart';


void main() {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Splashscreen()
    )
  );
}

