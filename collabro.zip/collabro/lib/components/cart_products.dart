import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';




class _cart_productsState extends State<cart_products> {
  var Products_on_cart = [
    {
      "name": "YAMAHA Mx88",
      "new_price": "79,990",
      "picture": "collabroresources/1.jpg"
    },

    {
      "name": "MODX6",
      "new_price": "199,999",
      "picture": "collabroresources/2.jpg"
    },

];
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: Products_on_cart.length,
        itemBuilder: (context, index) {
          return Single_cart_product(
            cart_product_name: Products_on_cart[index]["name"],
            cart_product_price: Products_on_cart[index]["new_price"],
            cart_product_image: Products_on_cart[index]["picture"],
          );
        });
  }
}

class cart_products extends StatefulWidget {
  @override
  _cart_productsState createState() => _cart_productsState();
}




class Single_cart_product extends StatelessWidget {
  final String cart_product_name;
  final String cart_product_image;
  final String cart_product_price;

  Single_cart_product({
    this.cart_product_image,
    this.cart_product_name,
    this.cart_product_price
  });


  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(15.0),
      child: Card(
        child: Container(
          child: ListTile(
            leading: SizedBox(width:150,
                height: 200,
                child: Image.asset(cart_product_image)),
            subtitle: new Column(
              children: <Widget>[
                new Row(
                  children: <Widget>[
                    Padding(padding: EdgeInsets.only(top: 20.0)),
                    Expanded(
                        child: new Text(cart_product_name,style: TextStyle(
                            fontSize: 18,fontWeight: FontWeight.bold,color: Colors.black),)
                    )
                  ],
                ),
                Divider(),
                new Row(
                  children: <Widget>[
                    Expanded(
                      child: new Text("₹"+cart_product_price,style: TextStyle(
                          fontSize: 18)),
                    ),
                    Expanded(
//                          padding: EdgeInsets.only(left: 25),
                      child: MaterialButton(
                        onPressed: (){},
                        color: Color.fromRGBO(42,62,112, 1),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(20.0))),
                        child: Text("Delete",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),),
                      ),
                    )

                   /* new Row(
                      children: <Widget>[

                      ],
                    )*/
                  ],
                )
              ],
            ),
          ),
          ),
        )
      );
  }
}
