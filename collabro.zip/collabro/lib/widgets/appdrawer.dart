
import 'package:collabro/products.dart';
import 'package:flutter/material.dart';

Widget appdrawer = new Drawer(
//APPDRAWER
  child: Container(
    color: Color.fromRGBO(42, 62, 112, 1),
//          color: Colors.black,
    child: new ListView(
      children: <Widget>[
        InkWell(
            onTap: () {

           },
            child: ListTile(
                title: Text(
                  'HOMEPAGE',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold),
                ),
                leading: Icon(Icons.home, color: Colors.white))),
        InkWell(
            onTap: () {},
            child: ListTile(
                title: Text('KEYBOARDS & PIANO',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold)),
                leading: Icon(Icons.music_note, color: Colors.white))),
        InkWell(
            onTap: () {

            },
            child: ListTile(
                title: Text('GUITARS & BASSES',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold)),
                leading: Icon(Icons.music_video, color: Colors.white))),
        InkWell(
            onTap: () {},
            child: ListTile(
                title: Text('DRUMS & PERCUSSION',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold)),
                leading: Icon(Icons.home, color: Colors.white))),
        InkWell(
          onTap: () {},
          child: ListTile(
              title: Text('STUDIO & RECORDING',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold)),
              leading: Icon(Icons.home, color: Colors.white)),
        ),
        InkWell(
            onTap: () {},
            child: ListTile(
                title: Text('WIND & STRING INSTRUMENTS',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold)),
                leading: Icon(Icons.home, color: Colors.white))),
        InkWell(
            onTap: () {},
            child: ListTile(
                title: Text('AMPLIFIERS & EFFECTS',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold)),
                leading: Icon(Icons.music_note, color: Colors.white))),
        InkWell(
            onTap: () {},
            child: ListTile(
                title: Text('Signout',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold)),
                leading: Icon(Icons.music_note, color: Colors.white)))
      ],
    ),
  ),
);
