import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:carousel_pro/carousel_pro.dart';

Widget carouselPro = new Container(
  height: 225.0,
  padding: EdgeInsets.all(0.0),
  child: Container(
    decoration: BoxDecoration(borderRadius: BorderRadius.circular(20.0),
        boxShadow: [BoxShadow(color: Colors.grey,blurRadius: 100,offset: Offset(1,1))]),
    child: new Carousel(
//      boxFit: BoxFit.cover,

      images: [
        AssetImage('collabroresources/1.jpg'),
        AssetImage('collabroresources/2.jpg'),
        AssetImage('collabroresources/3.jpg'),
        AssetImage('collabroresources/4.jpg'),
        AssetImage('collabroresources/5.jpg')
      ],
      autoplay: true,
      animationCurve: Curves.fastOutSlowIn,
      indicatorBgPadding: 2.0,
      dotSize: 4.0,
      borderRadius: true,
      dotBgColor: Colors.transparent,
      animationDuration: Duration(microseconds: 3000),
    ),
  ),
);