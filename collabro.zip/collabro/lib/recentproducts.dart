import 'package:collabro/product_details.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/material.dart';

import 'package:collabro/product_details.dart';

class recentprod extends StatefulWidget {
  @override
  _recentprodState createState() => _recentprodState();
}

class _recentprodState extends State<recentprod> {
  var products=[
    {
      "name":"YAMAHA Mx88",
      "old_price":"84,990",
      "new_price":"79,990",
      "picture":"collabroresources/1.jpg"
    },

    {
      "name":"MODX6",
      "old_price":"1,09,999",
      "new_price":"99,999",
      "picture":"collabroresources/2.jpg"
    },
    {
      "name":"MX49",
      "old_price":"45,990",
      "new_price":"41,990",
      "picture":"collabroresources/3.jpg"
    },
    {
      "name":"MONTAGE 6",
      "old_price":"2,89,990",
      "new_price":"2,79,990",
      "picture":"collabroresources/4.jpg"
    },


  ];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: Container(
        decoration:BoxDecoration(borderRadius: BorderRadius.circular(2.0),
          color: Color.fromRGBO(42,62,112, 1),),
        child: GridView.builder(
          physics: ScrollPhysics(),
          shrinkWrap: true,
            padding: EdgeInsets.all(5.0),
            itemCount: products.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
            itemBuilder: (BuildContext context, int index){
              return single_prod(
              prod_name: products[index]['name'],
              prod_picture: products[index]['picture'],
              prod_new_price: products[index]['new_price'],
              prod_old_price: products[index]['old_price'],
              );
        }),
      ),
    );
  }
}


//declaration and intantiation of variables
class single_prod extends StatelessWidget {
  final prod_name;
  final prod_picture;
  final prod_old_price;
  final prod_new_price;

  single_prod({
    this.prod_name,
    this.prod_picture,
    this.prod_old_price,
    this.prod_new_price,
  });


  //recent products list view onclick functions
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Card(
        margin: EdgeInsets.all(8.0),
        child: Hero(tag: prod_name,
          child: Material(
            child: InkWell(
              borderRadius: BorderRadius.circular(8.5),
              onTap: ()=> Navigator.of(context).push(MaterialPageRoute(
                builder: (context)=> new ProductDetails(
                  product_name_detail: prod_name,
                  product_image_detail: prod_picture,
                  product_old_price_detail: prod_old_price,
                  product_new_price_detail: prod_new_price,
                )
              )),




              child: Container(
                child: GridTile(
                  child: Image.asset(prod_picture, height: 200,),
                 ),
              ),
            ),

        ),),
      ),
    );
  }
}
