import 'package:cloud_firestore/cloud_firestore.dart';


class Product {
  static const NAME = "name";
  static const IMAGE_URL= "image_url";
  static const PRICE = "price";
  static const BRAND = "brand";
  static const OLD_PRICE = "old_price";
  static const MODEL = "model";
  static const DETAILS = "details";
  static const COLOR = "color";
  static const TYPE = "type";
  static const CATEGORY = "category";

  String _name;
  double _price;
  String _image_url;
  double _old_price;
  String _brand;
  String _model;
  String _details;
  String _color;
  String _type;
  String _category;

//GETTERS

  String get name => _name;
  double get price => _price;
  String get image_url => _image_url;
  double get old_price => _old_price;
  String get brand => _brand;
  String get model => _model;
  String get details => _details;
  String get color => _color;
  String get type => _type;
  String get category => _category;

//  NAMED CONSTRUCTORS

  Product.fromSnapshot(DocumentSnapshot snapshot){
    Map data = snapshot.data;
    _name = data[NAME];
    _price = data[PRICE];
    _image_url = data[IMAGE_URL];
    _brand = data[BRAND];
    _old_price = data[OLD_PRICE];
    _model = data[MODEL];
    _details = data[DETAILS];
    _color = data[COLOR];
    _type = data[TYPE];
    _category = data[CATEGORY];

  }
}
