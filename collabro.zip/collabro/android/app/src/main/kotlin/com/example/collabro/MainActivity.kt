package com.example.collabro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
